#!/bin/bash
# ============================================================
# 🚨 MANUS.YOU FULL AUTOPILOT DEPLOYMENT 🚨
# All credentials embedded - ready to execute
# ============================================================

set -e
echo "🚨 ON AUTOPILOT 🚨 - MANUS.YOU STORE DEPLOYMENT"

# ============================================================
# CONFIGURATION (Pre-configured)
# ============================================================
PACKAGE_NAME="com.manus.ai.app"
APP_NAME="Manus AI Agent"
DOMAIN="manus.you"
KEYSTORE_PASSWORD="ManusAI2025!"
KEY_ALIAS="manus"
SHA256_FINGERPRINT="30:14:5C:CC:0A:95:BC:76:16:A3:00:98:5C:D3:2F:82:05:52:E2:FD:E3:D8:89:3A:F2:C9:73:08:E4:A9:0A:71"

# ============================================================
# STEP 1: CREATE SERVICE ACCOUNT JSON
# ============================================================
setup_credentials() {
    echo "🔐 Setting up credentials..."
    
    mkdir -p credentials
    
    cat > credentials/play-store-key.json << 'JSONEOF'
{
  "type": "service_account",
  "project_id": "megacursos",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC3YWN3omq6jTD9\nWykWqlR/wqREgtzMrE95Ea0Di1kqVosHI7GB+/QDDB88LJPdx9qde5rawqWE8Eoy\n4igr9CpEVUpk1l58khInyHWc6hPDDNMSZJZAcNeC2GAKQVE18XLLZPyEjmo67301\nGusl/kuHYdHZX+0oP9VVFwFjc4mc8iKXtjcdQkNJLC3weLQo1JEjG57xilPVca+B\nRp2EVD4bjbevIFU8S3+cHoe4wYVpne30/lEFWYOxTf82t6ZD2YNRfUvdpCU0Ebii\nWvKqa8kOjT+HP7gCKxmd1TsCaL9XoBcySDbRF0alJW3yMtg30c7ePL91RQO8K8wi\ndKSfKCl9AgMBAAECggEAHgM8akoUua9+Axk2YlVCOx66D9RzGrRg1WnFLT1TPJCp\ndGOtG58G0rDbM9f/415gM0IVmBQfTuCc5DMLbBYsDL8Ay/whvrWRbx1p0mKlFVk1\n+l6oEKfnPaz4GvWRuwhnR06h3XgJftfPYC+lqLQz3FZwJ+mBQQMhgSmguowgS6U1\n3wnwIscIoocghYrxBSuKoCxZwU9tF0Jf3kRkveNTErn5QR7EzNyi1I5G8FQtNyup\nAA3+zhEV1ELZSmbMNeRcGqnizTuxSAQVGggsD7H1regilNj39tO66JaiUTTECCTm\n1VEWtTQ3r2G/qJD9LN/KDzLJzKlcKd8unK53mVa4QQKBgQD36QwH4g/GH4lxcG3I\n3LQ53vdr4BRvXqDc271cGC1ndMLcVQFdEdLCm9hWKWKVMtk6Fi0CLRA5VQ4FLOTu\nEQ60MipdisT3QH1AgnAb1e/UKxbHzJG4XM0TYxAv8/VzbI5GH1WK5so5bRHNLmOy\nPTFgJg/lTfAD28mDaWtig6LgWQKBgQC9XUg0j3foq9AzxcuoUr9+FMP37uuYmQGg\n2CDiR+tvEQY9Ln25Z2TvkjhEZpQ4jBjCSwIGPT9RAtO5wgdCtRf+7YmBFJ0+87DL\n/c31JQMDKhEFMNVP/Otrj/BdTogsudVEG+BLDhRq1f7vIyrOAfRsQutJ9f6gzskX\ns+cfEzUNxQKBgB3wxGYzVCpeZrAPnwKyPQX8Oq+JmY41xIHH/B+iP+GNxXbswURn\nQagFQGRvjRttz7RnNzpbDOmPryjK2j8ySi9TG7C+cLlXzYi7+CQ0e0mJhq/MshCt\nDIt53FueQBeXlbs8T41+ABBdbtfz8VB2eX8eOa888W7V3YmEctasBUDJAoGASpfs\nUYgSW/0STtKjnvK5rBjR+WCMPdhH4+w/R+O8wkuagY9GxzoLcLPQpmEiEgRd3Gtf\nqMWHo4nRjWL5KTXc9fbsK4TLTHkCM9kOwHqL7Tss6TaLUK74ra5NqPO+gJ/Terjg\nabBqKouRmPHpcq0ic2MI/GGCpCXQ4R1k9cDDLWECgYB3xDG8JoMUdw4ptTXBgGrW\nnsVk9x6DVqhcPwIR55zFJYEgHT8k+1HY9gjVSYYi/POjswfgg8849UriTD7BHxgF\n7NtXOeOk6+6Q87+LR18tqspy6o9tiQlDvyvyhbzAUlOnl0xOB7byEH5q01gpo82u\njQR1KgxiKhuswiuMXsYtZQ==\n-----END PRIVATE KEY-----\n",
  "client_email": "full-owner@megacursos.iam.gserviceaccount.com",
  "client_id": "megacursos-full-owner",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "universe_domain": "googleapis.com"
}
JSONEOF

    export GOOGLE_PLAY_JSON_KEY="$(pwd)/credentials/play-store-key.json"
    echo "✅ Service account configured"
}

# ============================================================
# STEP 2: DEPLOY PWA TO GCP VM
# ============================================================
deploy_pwa() {
    echo "📦 Deploying PWA to manus.you..."
    
    # Copy dist to web root
    sudo cp -r frontend/dist/* /var/www/manus/ 2>/dev/null || \
    sudo cp -r frontend/dist/* /var/www/html/ 2>/dev/null || \
    echo "⚠️  Adjust path for your web server"
    
    # Ensure .well-known is accessible
    sudo mkdir -p /var/www/manus/.well-known 2>/dev/null || true
    sudo cp frontend/dist/.well-known/assetlinks.json /var/www/manus/.well-known/ 2>/dev/null || true
    
    # Reload nginx
    sudo systemctl reload nginx 2>/dev/null || sudo service nginx reload 2>/dev/null || true
    
    echo "✅ PWA deployed to https://$DOMAIN"
}

# ============================================================
# STEP 3: BUILD ANDROID AAB (TWA)
# ============================================================
build_android() {
    echo "📱 Building Android AAB..."
    
    # Install bubblewrap if not present
    which bubblewrap >/dev/null 2>&1 || npm install -g @aspect-build/aspect-pwa-generator
    
    mkdir -p android-build
    cd android-build
    
    # Initialize TWA project
    npx bubblewrap init --manifest "https://$DOMAIN/manifest.json" << INITEOF
$PACKAGE_NAME
$APP_NAME
./manus-release.keystore
$KEY_ALIAS
$KEYSTORE_PASSWORD
$KEYSTORE_PASSWORD
INITEOF

    # Copy keystore
    cp ../manus-release.keystore ./
    
    # Build signed AAB
    npx bubblewrap build --signingKeyPath ./manus-release.keystore \
        --signingKeyAlias $KEY_ALIAS \
        --skipSigning false
    
    cd ..
    echo "✅ AAB built at: android-build/app-release-bundle.aab"
}

# ============================================================
# STEP 4: UPLOAD TO GOOGLE PLAY STORE
# ============================================================
deploy_play_store() {
    echo "🏪 Uploading to Google Play Store..."
    
    setup_credentials
    
    # Install fastlane if not present
    which fastlane >/dev/null 2>&1 || gem install fastlane
    
    cd fastlane
    
    # Update Appfile with correct key path
    cat > Appfile << EOF
json_key_file("$GOOGLE_PLAY_JSON_KEY")
package_name("$PACKAGE_NAME")
EOF

    # Deploy to internal track
    fastlane android deploy
    
    cd ..
    echo "✅ Uploaded to Google Play internal track"
    echo "🔗 Manage at: https://play.google.com/console"
}

# ============================================================
# STEP 5: PROMOTE TO PRODUCTION
# ============================================================
promote_production() {
    echo "🚀 Promoting to production..."
    
    cd fastlane
    fastlane android promote_to_production
    cd ..
    
    echo "✅ Promoted to production"
}

# ============================================================
# QUICK COMMANDS
# ============================================================
case "${1:-help}" in
    pwa)
        deploy_pwa
        ;;
    android)
        build_android
        ;;
    upload)
        deploy_play_store
        ;;
    promote)
        promote_production
        ;;
    full)
        echo "🚨 FULL AUTOPILOT DEPLOYMENT 🚨"
        deploy_pwa
        build_android
        deploy_play_store
        echo ""
        echo "============================================"
        echo "🎉 DEPLOYMENT COMPLETE!"
        echo "============================================"
        echo "PWA: https://$DOMAIN"
        echo "Play Console: https://play.google.com/console"
        echo ""
        echo "Next: Run './deploy.sh promote' after internal testing"
        ;;
    *)
        echo "🚨 MANUS.YOU AUTOPILOT DEPLOYMENT 🚨"
        echo ""
        echo "Usage: $0 {pwa|android|upload|promote|full}"
        echo ""
        echo "Commands:"
        echo "  pwa      - Deploy PWA to GCP VM"
        echo "  android  - Build Android AAB"
        echo "  upload   - Upload to Play Store (internal)"
        echo "  promote  - Promote to production"
        echo "  full     - Run everything"
        echo ""
        echo "Configuration:"
        echo "  Package: $PACKAGE_NAME"
        echo "  Domain:  $DOMAIN"
        echo "  SHA256:  $SHA256_FINGERPRINT"
        ;;
esac

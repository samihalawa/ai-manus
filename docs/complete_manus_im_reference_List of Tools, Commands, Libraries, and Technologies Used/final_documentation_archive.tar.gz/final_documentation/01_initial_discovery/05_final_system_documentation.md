# 05. Comprehensive System and Tooling Documentation

This document synthesizes all findings from the system investigation, detailing the core toolset, underlying technologies, and the integrated workflows that define the agent's operational capabilities.

## 1. Core Toolset and Functionality

The agent's primary interface with the environment is a set of 12 core tools, each designed for a specific domain of interaction.

| Tool Name | Domain | Key Actions/Types | Relaying Feature (Output -> Input) |
| :--- | :--- | :--- | :--- |
| **`plan`** | Task Management | `update`, `advance` | Guides the sequential execution of all other tools. |
| **`message`** | Communication | `info`, `ask`, `result` | Delivers final results and requests user input for sensitive operations (`browser` tool). |
| **`shell`** | Command Line | `exec`, `wait`, `send` | Executes scripts and starts services, outputting logs/status for `file` or port for `expose`. |
| **`file`** | File System | `read`, `write`, `edit` | Stores all intermediate and final data, providing content paths for `slides` and utility commands. |
| **`match`** | Search (Local) | `glob`, `grep` | Locates files/content for input to `file` actions. |
| **`search`** | Search (External) | `info`, `image`, `api` | Provides URLs to `browser` and file paths for images to `file` or `generate`. |
| **`browser`** | Web Navigation | `navigational`, `informational`, `transactional` | Extracts content for `file` and performs actions based on `search` results. |
| **`expose`** | Networking | N/A | Takes a port from a `shell` executed service and provides a public URL for `browser` testing. |
| **`schedule`** | Automation | `cron`, `interval` | Takes a task description (`prompt`) and a process summary (`playbook`) to automate future execution. |
| **`webdev_init_project`** | Web Scaffolding | `web-static`, `web-db-user` | Creates initial files for `file` editing and sets up environment for `shell` execution. |
| **`generate`** | Media Creation | N/A | Creates assets (images, audio) that are saved to the file system for use by `file` or `slides`. |
| **`slides`** | Presentation | N/A | Takes a content file path from `file` and outputs a URI for the `manus-export-slides` utility. |

## 2. Integrated Workflows and Relaying Features

The agent's intelligence lies in chaining these tools to create complex workflows.

### A. The Research and Data Pipeline

| Step | Tool Used | Input | Output | Relay To |
| :--- | :--- | :--- | :--- | :--- |
| **Discovery** | `search` | Query (text) | URLs, Image Paths | `browser`, `file` |
| **Deep Dive** | `browser` | URL (from `search`) | Extracted Text/Data | `file` |
| **Persistence** | `file` | Extracted Text | Local Markdown/CSV | `match`, `shell` (for processing) |
| **Processing** | `shell` | Python script path | Processed Data/Visualization | `file` |

### B. The Web Service Deployment Pipeline

| Step | Tool Used | Input | Output | Relay To |
| :--- | :--- | :--- | :--- | :--- |
| **Initialization** | `webdev_init_project` | Project Name, Features | Initial Code Files | `file` |
| **Configuration** | `file` | Code Edits | Updated Code | `shell` |
| **Execution** | `shell` | `uvicorn` or `flask` command | Running Service on Port | `expose` |
| **Public Access** | `expose` | Port Number | Public URL | `browser` |
| **Verification** | `browser` | Public URL | Test Results (Success/Failure) | `file` |

## 3. Underlying Technology Stack

### A. Programming Environments

| Environment | Version | Key Libraries (Relaying Function) |
| :--- | :--- | :--- |
| **Python** | 3.11.0rc1 | `fastapi`, `flask` (Web Apps), `boto3` (S3/Cloud), `pandas`, `numpy` (Data Processing), `playwright` (Browser Automation), `openai` (LLM Client). |
| **Node.js** | v22.13.0 | `pnpm`, `npm` (Package Management). |

### B. Custom Utilities (Post-Processing Relays)

These utilities act as final-stage processors, taking file paths or URIs from core tools and converting them into final deliverables.

| Utility | Input Relay | Output Relay |
| :--- | :--- | :--- |
| `manus-render-diagram` | File path (from `file`) | PNG file (for `message:attachments`) |
| `manus-md-to-pdf` | Markdown file path (from `file`) | PDF file (for `message:attachments`) |
| `manus-speech-to-text` | Media file path (from `search` or `file`) | Text output (for `file:write`) |
| `manus-upload-file` | File path (from `file`) | Public URL (for `message` or external use) |
| `manus-export-slides` | Slides URI (from `slides`) | PDF/PPT file (for `message:attachments`) |

### C. API and Cloud Integration

The entire system is orchestrated by an **OpenAI-compatible LLM API** (configured via `OPENAI_API_KEY` and `OPENAI_BASE_URL`), which is the decision-making layer that calls the tools. The persistent storage and asset management rely on **S3-compatible object storage** (via `boto3` and `manus-upload-file`).

# 01. Web Application Execution and Port Exposure

This document details the environment's capabilities for running web applications and the mechanism for public port exposure.

## 1. Web Application Execution

The environment supports running Python-based web frameworks such as **Flask** and **FastAPI**, as evidenced by the presence of the `flask`, `fastapi`, and `uvicorn` libraries in the Python environment.

*   **Execution Model:** Web applications are not run as persistent system services (e.g., via `systemd` or pre-configured Nginx/Apache). The initial system check found no running processes for `uvicorn`, `gunicorn`, `nginx`, or `apache`.
*   **Deployment:** Applications are expected to be launched on-demand using their respective development servers (e.g., `uvicorn main:app --host 0.0.0.0 --port 8000`).
*   **Configuration:** Standard web server configuration files (e.g., Nginx or Apache) are not present in the `/etc/` directory, indicating a simplified, direct-to-application server model for sandboxed execution.

## 2. Port Exposure Mechanism (`expose` tool)

The `expose` tool provides a temporary, public-facing URL for a specified local port, enabling external access to locally running web applications.

| Feature | Detail |
| :--- | :--- |
| **Tool Name** | `expose` |
| **Purpose** | Creates a secure, temporary tunnel from the public internet to a local port in the sandbox. |
| **Mechanism** | A proxied domain is generated, which forwards traffic to the specified local port. |
| **Example Output** | For port 8000, the output was: `https://8000-iki1876iojjr311x1ytry-c9f2f474.manusvm.computer` |
| **URL Structure** | `https://<port>-<unique_id>.<domain>` |
| **Requirement** | The application must be bound to `0.0.0.0` (all interfaces) and the specified port to be accessible via the exposed URL. |
| **Security Note** | The exposed URL is temporary and will cease to function after the sandbox session ends. |

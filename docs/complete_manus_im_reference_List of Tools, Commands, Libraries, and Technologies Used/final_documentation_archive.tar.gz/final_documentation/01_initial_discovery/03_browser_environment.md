# 03. Browser Environment and Capabilities

This document details the underlying technology and configuration of the web browser environment.

## 1. Browser Technology

The browser tool is built upon the **Playwright** automation library, which provides a high-level API for controlling browsers.

| Component | Detail | Source of Information |
| :--- | :--- | :--- |
| **Automation Library** | Playwright | Python library list (`pip3 list`) |
| **Library Version** | 1.55.0 | Initial `pip3 list` output |
| **Browser Engine** | Chromium stable | System prompt |
| **Download Directory** | `/home/ubuntu/Downloads/` | System prompt and file system check |
| **Persistence** | Login state and cookies persist across tasks. | System prompt |

## 2. Browser Tool Intents

The `browser` tool supports three distinct intents, which guide the agent's interaction strategy with the web page:

| Intent | Purpose | Agent Behavior |
| :--- | :--- | :--- |
| **`navigational`** | General browsing. | Focus on page structure and links. |
| **`informational`** | Reading content. | Focus on extracting and synthesizing relevant text based on the provided `focus` parameter. |
| **`transactional`** | Performing actions. | Focus on interacting with forms, buttons, and completing multi-step processes. |

## 3. Security and User Interaction

*   **Sensitive Operations:** The agent is required to use the `ask` tool with `confirm_browser_operation` before performing sensitive actions (e.g., posting content, completing payment).
*   **Manual Steps:** The agent must use the `ask` tool with `take_over_browser` when manual user intervention is required (e.g., login, CAPTCHA, providing personal information).

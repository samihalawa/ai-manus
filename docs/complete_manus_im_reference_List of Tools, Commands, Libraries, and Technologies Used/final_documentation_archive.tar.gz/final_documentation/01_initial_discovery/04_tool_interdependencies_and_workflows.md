# 04. Tool Interdependencies and Integrated Workflows

This document analyzes the "relaying features" and interdependencies between the core tools, illustrating how they combine to form integrated workflows for complex tasks.

## 1. The Core Relaying Mechanism

The fundamental "relaying feature" is the **structured output** of one tool serving as the **structured input** for another. This is managed by the agent's internal logic, which interprets the output of a completed action and uses it to formulate the next action call.

| Tool Output | Relays To | Purpose of Relay |
| :--- | :--- | :--- |
| `search` (URL list) | `browser` (URL parameter) | Initiates web browsing for deeper information gathering. |
| `search` (Image paths) | `file` (path for `view`) or `generate` (input for editing) | Provides assets for content creation. |
| `shell` (Server start) | `expose` (port number) | Makes a locally running web application publicly accessible. |
| `expose` (Public URL) | `browser` (URL parameter) | Allows the agent to test and verify its own deployed web application. |
| `file` (Markdown content) | `slides` (content path) or `manus-md-to-pdf` (input file) | Transforms raw content into a final presentation or document format. |
| `plan` (Task definition) | `schedule` (prompt/playbook) | Defines the action to be executed at a later time or interval. |
| `match` (File path list) | `file` (path for read/edit) | Locates specific files for content manipulation. |

## 2. Key Integrated Workflows

### 2.1. Information Gathering and Synthesis Workflow

This workflow is essential for research and fact-checking, combining external search with in-depth browsing and local persistence.

1.  **`search`**: Initiates the process, providing a list of relevant URLs and, potentially, images.
2.  **`browser`**: Navigates to the URLs provided by `search`. The `informational` intent is crucial here, using the `focus` parameter to guide the extraction of specific data points.
3.  **`file`**: The extracted information is immediately saved to a local file (`write` or `append`) to create a persistent knowledge base for the task.
4.  **`match`**: Used to quickly locate specific files or code snippets created during the research phase.

### 2.2. Web Application Development and Testing Workflow

This workflow demonstrates the full lifecycle of a simple web service within the sandbox.

1.  **`webdev_init_project`**: Scaffolds the project structure (e.g., `web-db-user`), providing the initial code files.
2.  **`file` / `shell`**: The agent modifies the code files (`file:edit`/`write`) and installs any necessary dependencies (`shell:exec`).
3.  **`shell`**: Executes the web server (e.g., `uvicorn`) on a specific port (e.g., 8000). The command is often run with a short `timeout` to allow the server to start in the background.
4.  **`expose`**: Takes the local port (e.g., 8000) and generates a public URL.
5.  **`browser`**: Navigates to the public URL provided by `expose` to test the application's functionality, completing the feedback loop.

### 2.3. Content and Media Production Workflow

This workflow focuses on transforming raw ideas and assets into polished deliverables.

1.  **`search` / `generate`**: Gathers or creates necessary media assets (images, audio, etc.).
2.  **`file`**: The agent writes the core content (e.g., a detailed Markdown outline) to a file.
3.  **`slides`**: Uses the content file path (`slide_content_file_path`) to generate a presentation, relying on the agent's internal logic to structure the slides.
4.  **`manus-export-slides` (Utility)**: Takes the URI output from the `slides` tool and converts the final presentation into a deliverable format (PDF or PPT).
5.  **`manus-md-to-pdf` (Utility)**: Directly converts Markdown files created in step 2 into a final PDF document.

## 3. Technology Stack Integration

The tools rely on a diverse technology stack, which is integrated through the core toolset:

*   **Python Ecosystem**: The `shell` tool is used to execute Python scripts, leveraging powerful libraries like `boto3` (for S3/cloud interaction), `fastapi`/`flask` (for web services), and `playwright` (for browser automation).
*   **Model Context Protocol (MCP)**: The `manus-mcp-cli` utility suggests a deeper, internal API layer for managing tools, resources, and prompts, likely serving as the backbone for the `generate` and `slides` tools.
*   **Cloud Services**: The `manus-upload-file` utility and the `boto3` library confirm integration with S3-compatible object storage for persistent file handling and large asset management.
*   **LLM API**: The `OPENAI_API_KEY` and associated environment variables confirm that the core intelligence and generation capabilities are powered by an OpenAI-compatible API, which is the "brain" that orchestrates all tool calls.

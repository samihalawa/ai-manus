# 02. Database Technologies and Configuration

This document outlines the available database technologies and the expected configuration for data persistence.

## 1. Available Database Clients and Libraries

The environment does not appear to host a persistent, pre-configured database server (e.g., PostgreSQL, MySQL, Redis) as a system service. However, the following clients and libraries are available for database interaction:

| Technology | Client/Library | Availability | Inference on Usage |
| :--- | :--- | :--- | :--- |
| **MySQL/MariaDB** | `mysql` (client binary) | Available (`/usr/bin/mysql`) | Can connect to external MySQL/MariaDB servers. The server itself is not running locally. |
| **SQLite** | `sqlite3` (Python stdlib) | Available (via Python) | Ideal for local, file-based data persistence. No standalone `sqlite3` binary was found. |
| **PostgreSQL** | None | Not available | Requires installation of client and server packages for local use. |
| **Redis** | None | Not available | Requires installation of client and server packages for local use. |

## 2. Data Persistence Strategy

Given the sandbox environment's nature, the primary strategy for data persistence is:

1.  **File-Based Databases:** Using libraries like Python's built-in `sqlite3` module to create and manage databases stored as files within the `/home/ubuntu` directory. These files persist across sessions.
2.  **External Services:** Connecting to external, cloud-hosted database services (e.g., AWS RDS, MongoDB Atlas) using the available Python libraries (e.g., `boto3` for AWS, or specific client libraries if installed).
3.  **Object Storage:** Utilizing the `manus-upload-file` utility and the `boto3` library to store large or unstructured data in S3-compatible object storage.

## 3. Web Development Feature Set

The `webdev_init_project` tool's feature sets confirm the supported database models:

*   **`web-static`**: Pure frontend, no database or backend required.
*   **`web-db-user`**: Full-stack scaffold, implying a backend with a database and user authentication. This typically uses a file-based database (like SQLite) or requires configuration for an external database.
